Made By Puma 			2021

5 easy steps to use.

1: Unzip the file.
2: Read the instructions.		<-----These are the instructions.
3: Run 'cd Java'.
4: Run 'java Main.java'
5: Hit CTRL+C to exit the program.
